public class Energia {
    public static int[][] energia = {
        {1, 3, 1},
        {1, 5, 1},
        {4, 2, 1}
    };
}
