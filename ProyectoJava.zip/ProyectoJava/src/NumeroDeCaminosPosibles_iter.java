public class NumeroDeCaminosPosibles_iter implements Runnable { //Declaración de la clase
    private int[][] mapa;   //Atributos privados
    private int resultado;

    public NumeroDeCaminosPosibles_iter(int[][] mapa) {     //Constructor
        this.mapa = mapa;
    }

    @Override    //Override
    public void run() {  //run (requerido por el runnable)
        resultado = contarCaminosIter(mapa);
    }

    public static int contarCaminosIter(int[][] mapa) {
        int n = mapa.length;
        int destinoFila = n - 2;
        int destinoCol = n - 2;

        int[][] caminos = new int[n][n];

        // Si el punto inicial está bloqueado, no hay caminos posibles
        if (mapa[0][0] == 0) {
            return 0;
        }

        caminos[0][0] = 1;

        for (int fila = 0; fila < n; fila++) {
            for (int col = 0; col < n; col++) {

                if (fila == 0 && col == 0) {
                    // ya inicializado
                } else if (mapa[fila][col] == 0) {
                    caminos[fila][col] = 0; // celda bloqueada
                } else {
                    int desdeArriba = (fila > 0) ? caminos[fila - 1][col] : 0;
                    int desdeIzquierda = (col > 0) ? caminos[fila][col - 1] : 0;
                    caminos[fila][col] = desdeArriba + desdeIzquierda;
                }
            }
        }

        return caminos[destinoFila][destinoCol];
    }

    public int getResultado() {
        return resultado;
    }
}
