public class CaminoDeMenorCoste { //Declaración de la clase que nos calcula el camino de menor costeº
    private int[][] energia;      //Declaración de una matriz de enteros que son los valores energéticos

    public CaminoDeMenorCoste(int[][] energia) { //Constructor
        this.energia = energia;
    }

    public static int caminoMinimoRec(int[][] energia, int i, int j) {  //Método que nos calcula el camino mínimo de forma recursiva
        int n = energia.length; //Variable n es la longitud de la matriz "energía", matriz cuadrada.
        int valor = 0;          //Inicializamos valor por 0 (asumimos que vale 0)
        if(i < 0 || i >= n || j < 0 || j >= n){ //Si la matriz es nula, (no se puede usar if == null al estar tratando enteros)
            valor = Integer.MAX_VALUE;          //Lo requiere el enunciado
        } else if(i == (n - 1) && j == (n-1)){  //Si energia[i][j] == salida, retorna energia[i][j]
            valor = energia[i][j];
        } else {   
            valor = energia[i][j] + Math.min(   //Si no estamos en ninguno de los casos base, calcula el mínimo de las energías
                caminoMinimoRec(energia, i + 1, j),
                caminoMinimoRec(energia, i, j + 1)
            );
        }
        return valor;                           //return solicitado
    }
}
