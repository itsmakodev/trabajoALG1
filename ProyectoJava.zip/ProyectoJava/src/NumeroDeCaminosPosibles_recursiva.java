public class NumeroDeCaminosPosibles_recursiva implements Runnable { //Declaración de la clase (implementa Runnable)
    private int[][] mapa;                                            //Atributos privados
    private int resultado;

    public NumeroDeCaminosPosibles_recursiva(int[][] mapa, int i, int j) {    //Constructor
        this.mapa = mapa;
    }

    @Override   //Override
    public void run() { //Run (requerido por el Runnable)
        resultado = contarCaminosRec(mapa, 0, 0);
    }

    public static int contarCaminosRec(int[][] mapa, int i, int j) {
        int n = mapa.length;
        int destinoFila = n - 2;
        int destinoCol = n - 2;

        // Fuera de límites
        if (i >= n || j >= n) {
            return 0;
        }

        // Celda bloqueada
        if (mapa[i][j] == 0) {
            return 0;
        }

        // Llegamos a la meta
        if (i == destinoFila && j == destinoCol) {
            return 1;
        }

        // Sumar caminos hacia abajo y hacia la derecha
        int caminos = contarCaminosRec(mapa, i + 1, j) + contarCaminosRec(mapa, i, j + 1);

        return caminos;
    }

    public int getResultado() {                 //Getter
        return resultado;
    }
}
