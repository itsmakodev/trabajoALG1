import java.util.Stack; //Import necesario

public class NumeroDeCaminosPosibles_iter implements Runnable { //Declaración de la clase (implementa Runnable)
    private int[][] mapa;                                       //Atributos necesarios
    private int resultado;

    public NumeroDeCaminosPosibles_iter(int[][] mapa) {        //Constructor
        this.mapa = mapa;
    }

    @Override       //Override
    public void run() { //Método run (requerido por el Runnable)
        resultado = contarCaminosIter(mapa);
    }

    public static int contarCaminosIter(int[][] mapa) { //Método que cuenta los caminos de forma iterativa
        int n = mapa.length;           //Declaración de n como la longitud del mapa.
        mapa[n - 2][n - 2] = 2;       
        //mapa[n-2][n-2] = 2, ya que 2 == meta, y también se nos dice en el enunciado que la meta está en dicha coordenada
        int totalCaminos = 0;   //Inicializamos los caminos posibles a cero

        Stack<int[]> pila = new Stack<>();  //Declaramos una pila de enteros
        pila.push(new int[]{0, 0});         //Inserta un arreglo de enteros {0,0} en la parte superior de la pila.
        
        while (!pila.isEmpty()) {           //Mientras que la pila no esté vacía...
            int[] pos = pila.pop();        
            //El vector posición elimina y devuelve el elemento que está en la parte superior de la pila
            int i = pos[0]; //La coordenada i es pos[0]
            int j = pos[1]; //La coordenada j es pos[1]

            if (i < 0 || i >= n || j < 0 || j >= n) //Si i o j es nulo continuar
                continue;                           
            if (mapa[i][j] == 0)                    //Si mapa[i]]j] == 0 (pared) continuar
                continue;
            if (mapa[i][j] == 2) {                  //Si mapa[i][j] == 2 (salida), sumar 1 al total de caminos y continuar
                totalCaminos++;
                continue;
            }
            
            pila.push(new int[]{i + 1, j});         //Colocar en pila
            pila.push(new int[]{i, j + 1});
            pila.push(new int[]{i + 1, j + 1});
        }

        return totalCaminos;                        //Return
    }

    public int getResultado() {                     //Getter del atributo resultado
        return resultado;
    }
}
