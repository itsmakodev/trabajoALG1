public class NumeroDeCaminosPosibles_recursiva implements Runnable { //Declaración de la clase (implementa Runnable)
    private int[][] mapa;                                            //Atributos privados
    private int resultado;

    public NumeroDeCaminosPosibles_recursiva(int[][] mapa, int i, int j) {    //Constructor
        this.mapa = mapa;
    }

    @Override   //Override
    public void run() { //Run (requerido por el Runnable)
        resultado = contarCaminosRec(mapa, 0, 0);
    }

    public static int contarCaminosRec(int[][] mapa, int i, int j) {    //Método que cuenta los caminos de forma recursiva
        int n = mapa.length;        //n es la longitud del mapa
        mapa[n - 2][n - 2] = 2;     //Salida se encuentra en mapa[n-2][n-2]

        if (i < 0 || i >= n || j < 0 || j >= n) //Si i o j es nulo, retornar 0
            return 0;
        if (mapa[i][j] == 0)                    //Si estamos en una pared, retornar 0
            return 0;
        if (mapa[i][j] == 2)                    //Si estamos en la salida, retornar 1
            return 1;

        int caminos = 0;                        //Declaración del atributo caminos y sumamos cada una de las posibles direcciones
        caminos += contarCaminosRec(mapa, i + 1, j);    
        caminos += contarCaminosRec(mapa, i, j + 1);     
        caminos += contarCaminosRec(mapa, i + 1, j + 1); 

        return caminos;                         //Return
    }

    public int getResultado() {                 //Getter
        return resultado;
    }
}
